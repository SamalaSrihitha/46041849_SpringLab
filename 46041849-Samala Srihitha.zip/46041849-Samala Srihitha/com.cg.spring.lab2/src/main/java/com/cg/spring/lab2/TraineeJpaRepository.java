package com.cg.spring.lab2;
import org.springframework.data.repository.CrudRepository;
public interface TraineeJpaRepository extends CrudRepository<Trainee, Integer> {

}
